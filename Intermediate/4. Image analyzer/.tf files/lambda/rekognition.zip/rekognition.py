import json
from os import environ
import logging
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

rekognition = boto3.client('rekognition')


def lambda_handler(event, context):

    try:
        # Parsear body recibido
        body = json.loads(event["body"])

        # Validar input
        if "fileKey" not in body:
            raise ValueError("fileKey missing in request body")

        key = body["fileKey"]
        bucket = environ["BUCKET"]

        # Imagen en S3
        image = {
            "S3Object": {
                "Bucket": bucket,
                "Name": key
            }
        }

        # Detectar caras
        response = rekognition.detect_faces(
            Image=image,
            Attributes=['ALL']
        )

        faces = response["FaceDetails"]

        # Si no hay caras
        if len(faces) == 0:
            raise ValueError("No faces detected")

        results = []

        # Procesar cada cara detectada
        for index, face in enumerate(faces):

            emotions = face["Emotions"]

            # Formatear emociones
            emotion_list = [
                {
                    "emotion": e["Type"],
                    "confidence": round(e["Confidence"], 2)
                }
                for e in emotions
            ]

            # Bounding box para saber posición de la cara
            box = face["BoundingBox"]

            results.append({
                "faceNumber": index + 1,
                "position": box,
                "emotions": emotion_list
            })

        logger.info(f"{len(faces)} faces detected in {key}")

        # Respuesta final
        return {
            "statusCode": 200,
            "body": json.dumps({
                "facesDetected": len(faces),
                "faces": results
            })
        }

    except ClientError as err:

        message = err.response["Error"]["Message"]
        logger.error(message)

        return {
            "statusCode": 400,
            "body": json.dumps({
                "error": "AWS Error",
                "message": message
            })
        }

    except ValueError as err:

        logger.warning(str(err))

        return {
            "statusCode": 400,
            "body": json.dumps({
                "error": "InvalidImage",
                "message": str(err)
            })
        }